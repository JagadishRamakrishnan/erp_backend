import ServiceCatalog from '../models/service_catalog.model.js';
import ServiceLineItem from '../models/service_line_item.model.js';
import User from '../../user/models/user.model.js';
import ServiceActionPlan from '../models/service_action_plan.model.js';
import db from '../../db/index.js';

class ServiceCatalogService {

  async getAll(filters = {}) {
    const where = {};
    if (filters.category) where.category = filters.category;
    if (filters.is_active !== undefined) where.is_active = filters.is_active === 'true';

    const res = await ServiceCatalog.findAll({
      where,
      include: [
        { model: ServiceLineItem, as: 'lineItems' },
        { model: ServiceActionPlan, as: 'actionPlans' },
        { model: User, as: 'createdBy', attributes: ['id', 'name'] }
      ],
      order: [['id', 'ASC']]
    });

    // Safeguard: Ensure General Sales Process (ID 0) is always there
    const hasDefault = res.some(s => s.id === 0 || s.id === '0' || s.name === 'General Sales Process');
    if (!hasDefault && Object.keys(where).length === 0) {
      res.unshift({
        id: 0,
        name: 'General Sales Process',
        category: 'Other',
        unit_price: 0,
        tax_percent: 18,
        description: 'Default sales process template (Always active)',
        is_active: true,
        lineItems: []
      });
    }
    return res;
  }

  async getById(id) {
    return await ServiceCatalog.findByPk(id, {
      include: [
        { model: ServiceLineItem, as: 'lineItems' },
        { model: ServiceActionPlan, as: 'actionPlans' },
        { model: User, as: 'createdBy', attributes: ['id', 'name'] }
      ]
    });
  }

  async create(data) {
    const { line_items = [], action_plans = [], ...serviceData } = data;

    const service = await ServiceCatalog.create(serviceData);

    if (line_items.length > 0) {
      const itemsWithServiceId = line_items.map(item => ({
        ...item,
        service_id: service.id
      }));
      await ServiceLineItem.bulkCreate(itemsWithServiceId);
    }

    if (action_plans.length > 0) {
      const plansWithServiceId = action_plans.map(plan => ({
        ...plan,
        service_id: service.id
      }));
      await ServiceActionPlan.bulkCreate(plansWithServiceId);
    }

    return this.getById(service.id);
  }

  async update(id, data) {
    const { line_items, action_plans, ...serviceData } = data;
    const service = await ServiceCatalog.findByPk(id);
    if (!service) return null;

    await service.update(serviceData);

    // Replace line items if provided
    if (line_items !== undefined) {
      await ServiceLineItem.destroy({ where: { service_id: id } });
      if (line_items.length > 0) {
        const itemsWithServiceId = line_items.map(item => ({
          ...item,
          service_id: id
        }));
        await ServiceLineItem.bulkCreate(itemsWithServiceId);
      }
    }

    // Replace action plans if provided
    if (action_plans !== undefined) {
      await ServiceActionPlan.destroy({ where: { service_id: id } });
      if (action_plans.length > 0) {
        const plansWithServiceId = action_plans.map(plan => ({
          ...plan,
          service_id: id
        }));
        await ServiceActionPlan.bulkCreate(plansWithServiceId);
      }
    }

    return this.getById(id);
  }

  async delete(id) {
    const service = await ServiceCatalog.findByPk(id);
    if (!service) return null;
    await ServiceLineItem.destroy({ where: { service_id: id } });
    await ServiceActionPlan.destroy({ where: { service_id: id } });
    await service.destroy();
    return true;
  }

  async getCategories() {
    const categories = await ServiceCatalog.findAll({
      attributes: [[db.sequelize.fn('DISTINCT', db.sequelize.col('category')), 'category']],
      where: { is_active: true }
    });
    return categories.map(c => c.category).filter(Boolean);
  }
}

export default new ServiceCatalogService();
